<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Login Page</title> -->
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        /* Navbar */
        .navbar {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-weight: 700;
            color: #800000;
            display: flex;
            align-items: center;
        }
        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }
        .nav-link {
            font-weight: 500;
            color: #555;
        }
        .nav-link:hover {
            color: #800000;
        }
        .btn-login, .btn-complaint {
            background-color: #800000;
            color: #fff;
            border-radius: 20px;
            margin-left: 10px;
        }
        .btn-login:hover, .btn-complaint:hover {
            background-color: #660000;
        }
        .btn-login, .btn-complaint {
            background-color: #800000;
            color: #fff;
            border-radius: 20px;
            margin-left: 10px;
        }
        .btn-login:hover, .btn-complaint:hover {
            background-color: #660000;
        }
        .login-section {
            padding: 80px 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-card {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            border-radius: 10px;
            width: 100%;
            max-width: 400px;
        }
        .btn-login {
            background-color: #800000;
            color: white;
            border-radius: 20px;
            font-size: 1rem;
            font-weight: 600;
        }
        .btn-login:hover {
            background-color: #660000;
        }
         /* Footer */
         footer {
            background-color: #800000;
            color: white;
            padding: 40px 20px;
            text-align: center;
        }
        footer a {
            color: #ffdd99;
            text-decoration: none;
        }
        footer a:hover {
            color: white;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="https://yt3.ggpht.com/a/AATXAJxBwQfG1jIAcEGk_spJ8CJBc90wfBhMa1yl6A=s900-c-k-c0xffffffff-no-rj-mo" alt="PCTE Logo">
                PCTE Hostel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="/#facilities">Facilities</a></li>
                    <li class="nav-item"><a class="nav-link" href="/#contact">Contact Us</a></li>
                    <li class="nav-item d-flex">
                    <!-- <a href="login.php" >  <button class="btn btn-login">Login</button> </a> -->
                      <!-- <a href="complaint.php" > <button class="btn btn-complaint">Complaint</button></a> -->
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        .carousel-item {
            height: 100vh;
            background-size: cover;
            background-position: center;
        }
        .carousel-caption {
            background: rgba(0, 0, 0, 0.6);
            border-radius: 10px;
            padding: 20px;
            
        }
        .carousel-caption h3, .carousel-caption p {
            color: #fff;
        }
        .carousel-indicators [data-bs-target] {
            background-color: #800000;
        }
        .carousel-control-prev-icon,
        .carousel-control-next-icon {
            background-color: #800000;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <div id="hostelCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
        <!-- Indicators -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#hostelCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#hostelCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#hostelCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        
        <!-- Slides -->
        <div class="carousel-inner">
            <!-- Slide 1 -->
            <div class="carousel-item active" style="background-image: url('https://pcte.edu.in/wp-content/uploads/2024/03/HOSTEL-1536x1024.jpg');">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Hostel A</h3>
                    <p>Modern rooms with all essential amenities for students.</p>
                </div>
            </div>
            <!-- Slide 2 -->
            <div class="carousel-item" style="background-image: url('https://cache.careers360.mobi/media/presets/720X480/colleges/social-media/media-gallery/25538/2020/1/31/Hostel%20of%20PCTE%20Group%20of%20Institutes%20Ludhiana_Hostel.jpg');">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Hostel B</h3>
                    <p>Peaceful environment with spacious lounges and gardens.</p>
                </div>
            </div>
            <!-- Slide 3 -->
            <div class="carousel-item" style="background-image: url('https://www.peoplesuniversity.edu.in/Dental/wp-content/uploads/2017/10/boyas-hostel.jpg');">
                <div class="carousel-caption d-none d-md-block">
                    <h3>Boys Hostel </h3>
                    <p>Affordable and comfortable with 24/7 security services.<br>Available for International Students also</p>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#hostelCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#hostelCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <?php include ('footer.php')?>
