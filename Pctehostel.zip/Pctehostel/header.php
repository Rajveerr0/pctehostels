<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PCTE Hostel Website</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <!-- AOS Library -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Navbar */
        .navbar {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-weight: 700;
            color: #800000;
            display: flex;
            align-items: center;
        }
        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }
        .nav-link {
            font-weight: 500;
            color: #555;
        }
        .nav-link:hover {
            text-decoration: none;
            color: #800000;
        }
        .btn-login, .btn-complaint {
            background-color: #800000;
            color: #fff;
            border-radius: 20px;
            margin-left: 10px;
        }
        .btn-login:hover, .btn-complaint:hover {
            background-color: #660000;
            color: white;
        }

        /* Hero Section */
        .hero {
            height: 100vh;
            position: relative;
            overflow: hidden;
        }
        .hero-slider {
            height: 100%;
            position: absolute;
            width: 100%;
        }
        .hero-slider img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
        }
        .hero-slider img.active {
            display: block;
        }
        .hero-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        .hero-content {
            z-index: 2;
            position: relative;
            text-align: center;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
        }
        .hero-title {
            font-size: 3rem;
            font-weight: 700;
        }
        .hero-subtitle {
            font-size: 1.5rem;
            margin-bottom: 20px;
        }
        .hero-btn {
            margin: 10px;
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 1.2rem;
            background-color: #800000;
            color: white;
            border: none;
            text-decoration-line: none;

        }
        .hero-btn:hover {
            background-color: #660000;
            color: #555;
        }

        /* Facilities Section */
        .facilities {
            padding: 80px 20px;
        }
        .facility-card {
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .facility-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .facility-icon {
            font-size: 3rem;
            color: #800000;
            margin-bottom: 15px;
        }
        .facility-title {
            font-weight: 600;
            margin-bottom: 10px;
        }
      
        /* Footer */
        footer {
            background-color: #800000;
            color: white;
            padding: 40px 20px;
            text-align: center;
        }
        footer a {
            color: #ffdd99;
            text-decoration: none;
        }
        footer a:hover {
            color: white;
        }
        .dropdown {
      position: relative;
      display: inline-block;
    }
.dropdown-btn {
      background-color: #8B0000;
      color: white;
      border: none;
      padding: 10px 20px;
      cursor: pointer;
      font-size: 16px;
      max-width: 150px;
      max-height: 50px;
      border-radius: 20px;
    }

    .dropdown-btn:hover {
      background-color: #5A0000;
    }

    .dropdown-content {
      display: none;
      position: absolute;
      background-color: #ffffff;
      box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
      z-index: 1;
      border-radius: 5px;
    }

    .dropdown-content a {
      color: #8B0000;
      padding: 10px 20px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover {
      background-color: #f1f1f1;
    }

    .dropdown:hover .dropdown-content {
      display: block;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .navbar {
        flex-direction: column;
      }

      .dropdown-btn {
        width: 100%;
      }

      .dropdown-content {
        width: 100%;
      }
    }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="https://yt3.ggpht.com/a/AATXAJxBwQfG1jIAcEGk_spJ8CJBc90wfBhMa1yl6A=s900-c-k-c0xffffffff-no-rj-mo" alt="PCTE Logo">
                PCTE Hostel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="#facilities">Facilities</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact Us</a></li>
                    <li class="nav-item d-flex">
                    <div class="dropdown">
  <button class="dropdown-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Login As
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" href="login.php">Student</a>
    <a class="dropdown-item" href="admin_login.php">Admin</a>
  </div>
</div>
<span style="color: white;" >_</span>                      <a href="complaint.php" > <button class="btn dropdown-btn">Complaint</button></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>