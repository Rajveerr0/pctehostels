<?php include_once('header.php') ?>
    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-slider">
            <img src="https://pcte.edu.in/wp-content/uploads/2024/03/page-2A-scaled.jpg" alt="Slide 1" class="active">
            <img src="https://pcte.edu.in/wp-content/uploads/2024/03/ROUND-1536x1024.jpg" alt="Slide 2">
            <img src="https://pcte.edu.in/wp-content/uploads/2019/02/32-1-scaled.jpg" alt="Slide 3">
        </div>
        <div class="hero-overlay"></div>
        <div class="hero-content"><br><br>
            <h1 class="hero-title">Welcome to PCTE Hostel</h1>
            <p class="hero-subtitle">Comfortable Living with Premium Facilities</p>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
           <a href="apply.php" class="hero-btn">Apply Now</a>
            <a href="explore.php" class="hero-btn">Explore More</a>
            <!-- <div class="slider-buttons">
                <button>Apply Now</button>
                <button>Explore More</button>
            </div> -->
        </div>
        
    </section>

    <!-- Facilities Section -->
    <section class="facilities container" id="facilities">
        <h2 class="text-center mb-5"><b>Our Facilities</b></h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="facility-card" data-aos="fade-up">
                    <i class="facility-icon bi bi-wifi"></i>
                    <h5 class="facility-title">Free Wi-Fi</h5>
                    <p>High-speed internet access available 24/7.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="facility-card" data-aos="fade-up" data-aos-delay="100">
                    <i class="facility-icon bi bi-building"></i>
                    <h5 class="facility-title">Spacious Rooms</h5>
                    <p>Well-furnished and comfortable rooms for students.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="facility-card" data-aos="fade-up" data-aos-delay="200">
                    <i class="facility-icon bi bi-cup"></i>
                    <h5 class="facility-title">Cafeteria</h5>
                    <p>Nutritious meals and snacks served daily.</p>
                </div>
            </div>
        </div>
    </section>
     <!-- Contact Section -->
     <section id="contact" class="contact-section py-5">
        <div class="container">
            <h2 class="text-center mb-5"><b>Contact Us</b></h2>
            <div class="row">
                <div class="col-md-6">
                    <h5>Contact Information</h5>
                    <p><i class="fas fa-phone"></i><a href="tel: 0161 -2888500" class="phone"> 0161-2888500</a></p>
                    <p><i class="fas fa-envelope"></i> <a href="mailto:info@pcte.edu.in" class="email"> info@pcte.edu.in</a>
                    </p>
                    <p><i class="fas fa-map-marker-alt"></i><a href="https://www.google.co.in/maps/search/Campus-2,Near+Baddowal+Cantt,+Ferozepur+Road,+Ludhiana-142021,+Punjab,+India/@30.8563338,75.7476498,14z/data=!3m1!4b1?entry=ttu&g_ep=EgoyMDI1MDExNS4wIKXMDSoASAFQAw%3D%3D"> Campus-2,Near Baddowal Cantt, Ferozepur Road, Ludhiana-142021, Punjab, India</a></p>
                </div>
                <div class="col-md-6">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6849.298675402816!2d75.74656129282245!3d30.868491248075806!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a818c8e8556c3%3A0x10d8f9b354b1565d!2sPCTE%20Group%20of%20Institutes!5e0!3m2!1sen!2sin!4v1737228677374!5m2!1sen!2sin"
                    width="400" height="200" style="border:0;" allowfullscreen="" loading="lazy">
                </iframe>
                </div>
            </div>
        </div>
    </section>
    <?php include ('footer.php')?>