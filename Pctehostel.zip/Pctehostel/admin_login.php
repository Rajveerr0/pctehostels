<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        /* Navbar */
        .navbar {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-weight: 700;
            color: #800000;
            display: flex;
            align-items: center;
        }
        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }
        .nav-link {
            font-weight: 500;
            color: #555;
        }
        .nav-link:hover {
            color: #800000;
        }
        .btn-login, .btn-complaint {
            background-color: #800000;
            color: #fff;
            border-radius: 20px;
            margin-left: 10px;
        }
        .btn-login:hover, .btn-complaint:hover {
            background-color: #660000;
        }
        .btn-login, .btn-complaint {
            background-color: #800000;
            color: #fff;
            border-radius: 20px;
            margin-left: 10px;
        }
        .btn-login:hover, .btn-complaint:hover {
            background-color: #660000;
        }
        .login-section {
            padding: 80px 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-card {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            border-radius: 10px;
            width: 100%;
            max-width: 400px;
        }
        .btn-login {
            background-color: #800000;
            color: white;
            border-radius: 20px;
            font-size: 1rem;
            font-weight: 600;
        }
        .btn-login:hover {
            background-color: #660000;
        }
         /* Footer */
         footer {
            background-color: #800000;
            color: white;
            padding: 40px 20px;
            text-align: center;
        }
        footer a {
            color: #ffdd99;
            text-decoration: none;
        }
        footer a:hover {
            color: white;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="https://yt3.ggpht.com/a/AATXAJxBwQfG1jIAcEGk_spJ8CJBc90wfBhMa1yl6A=s900-c-k-c0xffffffff-no-rj-mo" alt="PCTE Logo">
                PCTE Hostel
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="/#facilities">Facilities</a></li>
                    <li class="nav-item"><a class="nav-link" href="/#contact">Contact Us</a></li>
                    <li class="nav-item d-flex">
                    <!-- <a href="login.php" >  <button class="btn btn-login">Login</button> </a> -->
                      <!-- <a href="complaint.php" > <button class="btn btn-complaint">Complaint</button></a> -->
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Login Form -->
    <section class="login-section">
        <div class="login-card">
            <h2 class="text-center mb-4">Admin Login</h2>
            <form method="post">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" id="name" class="form-control" placeholder="Enter your username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" id="password" class="form-control" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="btn btn-login w-100">Login</button>
            </form>
        </div>
    </section>
    <?php
// Start the session
session_start();

// Database configuration
$host = 'localhost'; // Database host
$db_name = 'login'; // Database name
$username = 'root'; // Database username
$password = ''; // Database password

// Create a connection
$conn = new mysqli($host, $username, $password, $db_name);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get input values
    $user_email = $conn->real_escape_string($_POST['name']);
    $user_password = $conn->real_escape_string($_POST['password']);

    // Query to check user credentials
    $sql = "SELECT * FROM loginadmin WHERE `name` = '$user_email' AND password = '$user_password'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        // Fetch user data
        $user = $result->fetch_assoc();

        // Set session variables
        $_SESSION['id'] = $user['id'];
        $_SESSION['name'] = $user['name'];

        // Redirect to a protected page
        header("Location: login.php");
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>
    <!-- Footer -->
    <footer>
        <p>&copy; 2025 PCTE Hostel. All Rights Reserved. | <a href="#">Privacy Policy</a></p>
    </footer>
</body>
</html>
