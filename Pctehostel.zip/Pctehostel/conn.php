<?php
    $server = "localhost";
    $userName = "root";
    $passWord = "";
    $dataBase = "hostel";

    $conn = mysqli_connect($server,$userName,$passWord,$dataBase);
    if(!$conn)
    {
        die("sorry we are fialed to connect");
    }
?>